from PIL import Image
import os
# Function to change the image size
def changeImageSize(maxWidth, 
                    maxHeight, 
                    image):
    
    widthRatio  = maxWidth/image.size[0]
    heightRatio = maxHeight/image.size[1]

    newWidth    = int(widthRatio*image.size[0])
    newHeight   = int(heightRatio*image.size[1])

    newImage    = image.resize((newWidth, newHeight))
    return newImage


src_lst = os.listdir("./source")
tgt_lst = os.listdir("./target")
res_path = "./results"


for src in src_lst:
    for tgt in tgt_lst:
        print(src,"\n", tgt)
        # Take two images for blending them together   
        Source = Image.open(os.path.join("./source", src))
        Target = Image.open(os.path.join("./target", tgt))

        # Make the images of uniform size
        image3 = changeImageSize(800, 500, Source)
        image4 = changeImageSize(800, 500, Target)
        # print(image3.size, image4.size )
        # Make sure images got an alpha channel
        image5 = image3.convert("RGBA")
        image6 = image4.convert("RGBA")
        try:
            Result = Image.blend(image5, image6, alpha=.65)
        except:
            print("Images are not blended : ", src, tgt)
        # Output = Result.save("/home/ayush-ai/Music/ali/result/result14-15.png") 
        res = f"result-{src.split('.')[0]   }-{tgt.split('.')[0]}.png"
        Output = Result.save(f"./results/{res}") 
        print("Image Blending compeleted successfully.")
